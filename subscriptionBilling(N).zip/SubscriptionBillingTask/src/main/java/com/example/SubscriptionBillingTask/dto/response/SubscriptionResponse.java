package com.example.SubscriptionBillingTask.dto.response;

import com.example.SubscriptionBillingTask.enums.SubscriptionStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter 
@Setter
@NoArgsConstructor 
@AllArgsConstructor
@Builder
public class SubscriptionResponse {
    private Long id;
    private Long userId;
    private String userName;
    private Long planId;
    private String planName;
    private SubscriptionStatus status;
    private LocalDate startDate;
    private LocalDate endDate;
    private LocalDate nextBillingDate;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
