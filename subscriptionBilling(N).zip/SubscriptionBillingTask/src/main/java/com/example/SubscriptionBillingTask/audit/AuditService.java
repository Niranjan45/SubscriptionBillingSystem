package com.example.SubscriptionBillingTask.audit;



import com.example.SubscriptionBillingTask.model.AuditLog;
import com.example.SubscriptionBillingTask.service.repository.AuditLogRepository;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service

public class AuditService {
@Autowired
    private AuditLogRepository auditLogRepository;

    public void log(String entity, String action, Long entityId, String details, String performedBy) {
    	
        AuditLog auditLog = new AuditLog();
        auditLog.setAction(action);
        auditLog.setEntity(entity);
        auditLog.setDetails(details);
        auditLog.setPerformedBy(performedBy);
          
        auditLogRepository.save(auditLog);
        log.info("AUDIT - Entity: {}, Action: {}, EntityId: {}, By: {}", entity, action, entityId, performedBy);
       
    }
@Autowired
	public AuditService() {
		super();
	}

	public AuditService(AuditLogRepository auditLogRepository) {
		super();
		this.auditLogRepository = auditLogRepository;
	}
	public AuditLogRepository getAuditLogRepository() {
		return auditLogRepository;
	}
	public void setAuditLogRepository(AuditLogRepository auditLogRepository) {
		this.auditLogRepository = auditLogRepository;
	}
	public static org.slf4j.Logger getLog() {
		return log;
	}
    
}