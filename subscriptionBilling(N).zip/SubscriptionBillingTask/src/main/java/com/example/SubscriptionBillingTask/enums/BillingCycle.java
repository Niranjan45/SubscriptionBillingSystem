package com.example.SubscriptionBillingTask.enums;


public enum BillingCycle {
    MONTHLY, QUARTERLY, HALF_YEARLY, YEARLY
}
