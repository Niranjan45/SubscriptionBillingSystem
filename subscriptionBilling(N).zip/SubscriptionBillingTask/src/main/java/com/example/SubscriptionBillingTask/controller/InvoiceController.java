package com.example.SubscriptionBillingTask.controller;


import com.example.SubscriptionBillingTask.dto.request.InvoiceRequest;
import com.example.SubscriptionBillingTask.dto.response.InvoiceResponse;
import com.example.SubscriptionBillingTask.enums.InvoiceStatus;
import com.example.SubscriptionBillingTask.service.InvoiceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/invoices")
@RequiredArgsConstructor
@Tag(name = "Invoice Management", description = "APIs for managing invoices")
public class InvoiceController {

    private final InvoiceService invoiceService;

    @PostMapping
    @Operation(summary = "Generate invoice")
    public ResponseEntity<InvoiceResponse> generateInvoice(@Valid @RequestBody InvoiceRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(invoiceService.generateInvoice(request));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get invoice by ID")
    public ResponseEntity<InvoiceResponse> getInvoiceById(@PathVariable Long id) {
        return ResponseEntity.ok(invoiceService.getInvoiceById(id));
    }

    @GetMapping
    @Operation(summary = "Get all invoices with pagination")
    public ResponseEntity<Page<InvoiceResponse>> getAllInvoices(Pageable pageable) {
        return ResponseEntity.ok(invoiceService.getAllInvoices(pageable));
    }

    @GetMapping("/status/{status}")
    @Operation(summary = "Get invoices by status")
    public ResponseEntity<Page<InvoiceResponse>> getByStatus(
            @PathVariable InvoiceStatus status, Pageable pageable) {
        return ResponseEntity.ok(invoiceService.getInvoicesByStatus(status, pageable));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get invoices by user")
    public ResponseEntity<Page<InvoiceResponse>> getByUser(
            @PathVariable Long userId, Pageable pageable) {
        return ResponseEntity.ok(invoiceService.getInvoicesByUser(userId, pageable));
    }

    @GetMapping("/subscription/{subscriptionId}")
    @Operation(summary = "Get invoices by subscription")
    public ResponseEntity<Page<InvoiceResponse>> getBySubscription(
            @PathVariable Long subscriptionId, Pageable pageable) {
        return ResponseEntity.ok(invoiceService.getInvoicesBySubscription(subscriptionId, pageable));
    }

    @PatchMapping("/{id}/pay")
    @Operation(summary = "Mark invoice as paid")
    public ResponseEntity<InvoiceResponse> markAsPaid(@PathVariable Long id) {
        return ResponseEntity.ok(invoiceService.markAsPaid(id));
    }

    @PatchMapping("/{id}/cancel")
    @Operation(summary = "Cancel invoice")
    public ResponseEntity<InvoiceResponse> cancelInvoice(@PathVariable Long id) {
        return ResponseEntity.ok(invoiceService.cancelInvoice(id));
    }
}