package com.example.SubscriptionBillingTask.dto.response;



import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DashboardResponse {
    private long totalUsers;
    private long activeSubscriptions;
    private long cancelledSubscriptions;
    private long expiredSubscriptions;
    private long totalPlans;
    private long totalInvoices;
    private long paidInvoices;
    private long unpaidInvoices;
    private long overdueInvoices;
    private BigDecimal totalRevenue;
    private BigDecimal revenueThisMonth;
}