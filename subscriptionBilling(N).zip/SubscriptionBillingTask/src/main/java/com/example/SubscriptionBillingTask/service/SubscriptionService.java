package com.example.SubscriptionBillingTask.service;


import com.example.SubscriptionBillingTask.audit.AuditService;
import com.example.SubscriptionBillingTask.dto.request.SubscriptionRequest;
import com.example.SubscriptionBillingTask.dto.response.SubscriptionResponse;
import com.example.SubscriptionBillingTask.enums.BillingCycle;
import com.example.SubscriptionBillingTask.enums.PlanStatus;
import com.example.SubscriptionBillingTask.enums.SubscriptionStatus;
import com.example.SubscriptionBillingTask.exception.BusinessException;
import com.example.SubscriptionBillingTask.exception.ResourceNotFoundException;
import com.example.SubscriptionBillingTask.model.Plan;
import com.example.SubscriptionBillingTask.model.Subscription;
import com.example.SubscriptionBillingTask.model.User;
import com.example.SubscriptionBillingTask.service.repository.SubscriptionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Slf4j
@Service
@RequiredArgsConstructor
public class SubscriptionService {

    private final SubscriptionRepository subscriptionRepository;
    private final UserService userService;
    private final PlanService planService;
    private final AuditService auditService;

    public SubscriptionResponse createSubscription(SubscriptionRequest request) {
        User user = userService.findById(request.getUserId());
        Plan plan = planService.findById(request.getPlanId());

        if (plan.getStatus() != PlanStatus.ACTIVE) {
            throw new BusinessException("Cannot subscribe to an inactive plan");
        }

        boolean hasActive = !subscriptionRepository
                .findByUserIdAndStatus(user.getId(), SubscriptionStatus.ACTIVE).isEmpty();
        if (hasActive) {
            throw new BusinessException("User already has an active subscription");
        }

        LocalDate nextBillingDate = calculateNextBillingDate(request.getStartDate(), plan.getBillingCycle());

        Subscription subscription = Subscription.builder()
                .user(user)
                .plan(plan)
                .status(SubscriptionStatus.ACTIVE)
                .startDate(request.getStartDate())
                .nextBillingDate(nextBillingDate)
                .build();

        Subscription saved = subscriptionRepository.save(subscription);
        auditService.log("SUBSCRIPTION", "CREATE", saved.getId(),
                "Subscription created for user: " + user.getEmail(), "SYSTEM");
        return toResponse(saved);
    }

    public SubscriptionResponse getSubscriptionById(Long id) {
        return toResponse(findById(id));
    }

    public Page<SubscriptionResponse> getAllSubscriptions(Pageable pageable) {
        return subscriptionRepository.findAll(pageable).map(this::toResponse);
    }

    public Page<SubscriptionResponse> getSubscriptionsByUser(Long userId, Pageable pageable) {
        User user = userService.findById(userId);
        return subscriptionRepository.findByUser(user, pageable).map(this::toResponse);
    }

    public Page<SubscriptionResponse> getSubscriptionsByStatus(SubscriptionStatus status, Pageable pageable) {
        return subscriptionRepository.findByStatus(status, pageable).map(this::toResponse);
    }

    public SubscriptionResponse cancelSubscription(Long id) {
        Subscription subscription = findById(id);
        if (subscription.getStatus() == SubscriptionStatus.CANCELLED) {
            throw new BusinessException("Subscription is already cancelled");
        }
        subscription.setStatus(SubscriptionStatus.CANCELLED);
        subscription.setEndDate(LocalDate.now());
        Subscription saved = subscriptionRepository.save(subscription);
        auditService.log("SUBSCRIPTION", "CANCEL", id, "Subscription cancelled", "SYSTEM");
        return toResponse(saved);
    }

    public SubscriptionResponse pauseSubscription(Long id) {
        Subscription subscription = findById(id);
        if (subscription.getStatus() != SubscriptionStatus.ACTIVE) {
            throw new BusinessException("Only active subscriptions can be paused");
        }
        subscription.setStatus(SubscriptionStatus.PAUSED);
        Subscription saved = subscriptionRepository.save(subscription);
        auditService.log("SUBSCRIPTION", "PAUSE", id, "Subscription paused", "SYSTEM");
        return toResponse(saved);
    }

    public SubscriptionResponse resumeSubscription(Long id) {
        Subscription subscription = findById(id);
        if (subscription.getStatus() != SubscriptionStatus.PAUSED) {
            throw new BusinessException("Only paused subscriptions can be resumed");
        }
        subscription.setStatus(SubscriptionStatus.ACTIVE);
        Subscription saved = subscriptionRepository.save(subscription);
        auditService.log("SUBSCRIPTION", "RESUME", id, "Subscription resumed", "SYSTEM");
        return toResponse(saved);
    }

    public Subscription findById(Long id) {
        return subscriptionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subscription not found with id: " + id));
    }

    private LocalDate calculateNextBillingDate(LocalDate startDate, BillingCycle cycle) {
        return switch (cycle) {
            case MONTHLY -> startDate.plusMonths(1);
            case QUARTERLY -> startDate.plusMonths(3);
            case HALF_YEARLY -> startDate.plusMonths(6);
            case YEARLY -> startDate.plusYears(1);
        };
    }

    private SubscriptionResponse toResponse(Subscription s) {
        return SubscriptionResponse.builder()
                .id(s.getId())
                .userId(s.getUser().getId())
                .userName(s.getUser().getName())
                .planId(s.getPlan().getId())
                .planName(s.getPlan().getName())
                .status(s.getStatus())
                .startDate(s.getStartDate())
                .endDate(s.getEndDate())
                .nextBillingDate(s.getNextBillingDate())
                .createdAt(s.getCreatedAt())
                .updatedAt(s.getUpdatedAt())
                .build();
    }
}