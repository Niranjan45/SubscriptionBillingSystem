package com.example.SubscriptionBillingTask.enums;


public enum SubscriptionStatus {
    ACTIVE, CANCELLED, EXPIRED, PAUSED, PENDING
}
