package com.example.SubscriptionBillingTask.service;

import com.example.SubscriptionBillingTask.audit.AuditService;
import com.example.SubscriptionBillingTask.dto.request.PlanRequest;
import com.example.SubscriptionBillingTask.dto.response.PlanResponse;
import com.example.SubscriptionBillingTask.enums.BillingCycle;
import com.example.SubscriptionBillingTask.enums.PlanStatus;
import com.example.SubscriptionBillingTask.exception.BusinessException;
import com.example.SubscriptionBillingTask.exception.ResourceNotFoundException;
import com.example.SubscriptionBillingTask.model.Plan;
import com.example.SubscriptionBillingTask.service.repository.PlanRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class PlanService {

    private final PlanRepository planRepository;
    private final AuditService auditService;

    public PlanResponse createPlan(PlanRequest request) {
        if (planRepository.existsByName(request.getName())) {
            throw new BusinessException("Plan already exists with name: " + request.getName());
        }
        Plan plan = Plan.builder()
                .name(request.getName())
                .description(request.getDescription())
                .price(request.getPrice())
                .billingCycle(request.getBillingCycle())
                .status(request.getStatus())
                .trialDays(request.getTrialDays())
                .durationDays(request.getDurationDays())
                .build();
        Plan saved = planRepository.save(plan);
        auditService.log("PLAN", "CREATE", saved.getId(), "Plan created: " + saved.getName(), "SYSTEM");
        return toResponse(saved);
    }

    public PlanResponse getPlanById(Long id) {
        return toResponse(findById(id));
    }

    public Page<PlanResponse> getAllPlans(Pageable pageable) {
        return planRepository.findAll(pageable).map(this::toResponse);
    }

    public Page<PlanResponse> getPlansByStatus(PlanStatus status, Pageable pageable) {
        return planRepository.findByStatus(status, pageable).map(this::toResponse);
    }

    public Page<PlanResponse> getPlansByBillingCycle(BillingCycle cycle, Pageable pageable) {
        return planRepository.findByBillingCycle(cycle, pageable).map(this::toResponse);
    }

    public PlanResponse updatePlan(Long id, PlanRequest request) {
        Plan plan = findById(id);
        plan.setName(request.getName());
        plan.setDescription(request.getDescription());
        plan.setPrice(request.getPrice());
        plan.setBillingCycle(request.getBillingCycle());
        plan.setStatus(request.getStatus());
        plan.setTrialDays(request.getTrialDays());
        plan.setDurationDays(request.getDurationDays());
        Plan saved = planRepository.save(plan);
        auditService.log("PLAN", "UPDATE", saved.getId(), "Plan updated: " + saved.getName(), "SYSTEM");
        return toResponse(saved);
    }

    public void deletePlan(Long id) {
        Plan plan = findById(id);
        planRepository.delete(plan);
        auditService.log("PLAN", "DELETE", id, "Plan deleted", "SYSTEM");
    }

    public Plan findById(Long id) {
        return planRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Plan not found with id: " + id));
    }

    private PlanResponse toResponse(Plan p) {
        return PlanResponse.builder()
                .id(p.getId())
                .name(p.getName())
                .description(p.getDescription())
                .price(p.getPrice())
                .billingCycle(p.getBillingCycle())
                .status(p.getStatus())
                .trialDays(p.getTrialDays())
                
                .createdAt(p.getCreatedAt())
                .updatedAt(p.getUpdatedAt())
                .build();
    }
}