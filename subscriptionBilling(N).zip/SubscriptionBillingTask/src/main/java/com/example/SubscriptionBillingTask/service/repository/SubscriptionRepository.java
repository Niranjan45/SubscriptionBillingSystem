package com.example.SubscriptionBillingTask.service.repository;


import com.example.SubscriptionBillingTask.enums.SubscriptionStatus;
import com.example.SubscriptionBillingTask.model.Subscription;
import com.example.SubscriptionBillingTask.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {
    Page<Subscription> findByUser(User user, Pageable pageable);
    Page<Subscription> findByStatus(SubscriptionStatus status, Pageable pageable);
    List<Subscription> findByUserAndStatus(User user, SubscriptionStatus status);
    long countByStatus(SubscriptionStatus status);

    @Query("SELECT s FROM Subscription s WHERE s.user.id = :userId AND s.status = :status")
    List<Subscription> findByUserIdAndStatus(@Param("userId") Long userId,
                                              @Param("status") SubscriptionStatus status);
}