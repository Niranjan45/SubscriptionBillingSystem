package com.example.SubscriptionBillingTask.controller;

import com.example.SubscriptionBillingTask.dto.request.PlanRequest;
import com.example.SubscriptionBillingTask.dto.response.PlanResponse;
import com.example.SubscriptionBillingTask.enums.BillingCycle;
import com.example.SubscriptionBillingTask.enums.PlanStatus;
import com.example.SubscriptionBillingTask.service.PlanService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/plans")
@RequiredArgsConstructor
@Tag(name = "Plan Management", description = "APIs for managing subscription plans")
public class PlanController {

    private final PlanService planService;

    @PostMapping
    @Operation(summary = "Create a new plan")
    public ResponseEntity<PlanResponse> createPlan(@Valid @RequestBody PlanRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(planService.createPlan(request));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get plan by ID")
    public ResponseEntity<PlanResponse> getPlanById(@PathVariable Long id) {
        return ResponseEntity.ok(planService.getPlanById(id));
    }

    @GetMapping
    @Operation(summary = "Get all plans with pagination")
    public ResponseEntity<Page<PlanResponse>> getAllPlans(Pageable pageable) {
        return ResponseEntity.ok(planService.getAllPlans(pageable));
    }

    @GetMapping("/status/{status}")
    @Operation(summary = "Get plans by status")
    public ResponseEntity<Page<PlanResponse>> getPlansByStatus(
            @PathVariable PlanStatus status, Pageable pageable) {
        return ResponseEntity.ok(planService.getPlansByStatus(status, pageable));
    }

    @GetMapping("/billing-cycle/{cycle}")
    @Operation(summary = "Get plans by billing cycle")
    public ResponseEntity<Page<PlanResponse>> getPlansByBillingCycle(
            @PathVariable BillingCycle cycle, Pageable pageable) {
        return ResponseEntity.ok(planService.getPlansByBillingCycle(cycle, pageable));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update plan")
    public ResponseEntity<PlanResponse> updatePlan(
            @PathVariable Long id, @Valid @RequestBody PlanRequest request) {
        return ResponseEntity.ok(planService.updatePlan(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete plan")
    public ResponseEntity<Void> deletePlan(@PathVariable Long id) {
        planService.deletePlan(id);
        return ResponseEntity.noContent().build();
    }
}