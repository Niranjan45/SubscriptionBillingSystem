package com.example.SubscriptionBillingTask.service.repository;

import com.example.SubscriptionBillingTask.enums.InvoiceStatus;
import com.example.SubscriptionBillingTask.model.Invoice;
import com.example.SubscriptionBillingTask.model.Subscription;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    Page<Invoice> findBySubscription(Subscription subscription, Pageable pageable);
    Page<Invoice> findByStatus(InvoiceStatus status, Pageable pageable);
    List<Invoice> findByStatusAndDueDateBefore(InvoiceStatus status, LocalDate date);
    long countByStatus(InvoiceStatus status);

    @Query("SELECT COALESCE(SUM(i.amount), 0) FROM Invoice i WHERE i.status = 'PAID'")
    BigDecimal getTotalRevenue();

    @Query("SELECT COALESCE(SUM(i.amount), 0) FROM Invoice i WHERE i.status = 'PAID' " +
           "AND MONTH(i.paidDate) = MONTH(CURRENT_DATE) AND YEAR(i.paidDate) = YEAR(CURRENT_DATE)")
    BigDecimal getRevenueThisMonth();

    @Query("SELECT i FROM Invoice i WHERE i.subscription.user.id = :userId")
    Page<Invoice> findByUserId(@Param("userId") Long userId, Pageable pageable);
}