package com.example.SubscriptionBillingTask.enums;



public enum InvoiceStatus {
    PAID, UNPAID, OVERDUE, CANCELLED
}
