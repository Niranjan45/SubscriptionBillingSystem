package com.example.SubscriptionBillingTask.service.repository;


import com.example.SubscriptionBillingTask.enums.BillingCycle;
import com.example.SubscriptionBillingTask.enums.PlanStatus;
import com.example.SubscriptionBillingTask.model.Plan;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlanRepository extends JpaRepository<Plan, Long> {
    Page<Plan> findByStatus(PlanStatus status, Pageable pageable);
    Page<Plan> findByBillingCycle(BillingCycle billingCycle, Pageable pageable);
    boolean existsByName(String name);
}
