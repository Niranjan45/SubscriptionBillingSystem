package com.example.SubscriptionBillingTask.service;



import com.example.SubscriptionBillingTask.dto.response.DashboardResponse;
import com.example.SubscriptionBillingTask.enums.InvoiceStatus;
import com.example.SubscriptionBillingTask.enums.SubscriptionStatus;
import com.example.SubscriptionBillingTask.service.repository.InvoiceRepository;
import com.example.SubscriptionBillingTask.service.repository.PlanRepository;
import com.example.SubscriptionBillingTask.service.repository.SubscriptionRepository;
import com.example.SubscriptionBillingTask.service.repository.UserRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final UserRepository userRepository;
    private final PlanRepository planRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final InvoiceRepository invoiceRepository;

    public DashboardResponse getDashboard() {
        return DashboardResponse.builder()
                .totalUsers(userRepository.count())
                .totalPlans(planRepository.count())
                .activeSubscriptions(subscriptionRepository.countByStatus(SubscriptionStatus.ACTIVE))
                .cancelledSubscriptions(subscriptionRepository.countByStatus(SubscriptionStatus.CANCELLED))
                .expiredSubscriptions(subscriptionRepository.countByStatus(SubscriptionStatus.EXPIRED))
                .totalInvoices(invoiceRepository.count())
                .paidInvoices(invoiceRepository.countByStatus(InvoiceStatus.PAID))
                .unpaidInvoices(invoiceRepository.countByStatus(InvoiceStatus.UNPAID))
                .overdueInvoices(invoiceRepository.countByStatus(InvoiceStatus.OVERDUE))
                .totalRevenue(invoiceRepository.getTotalRevenue())
                .revenueThisMonth(invoiceRepository.getRevenueThisMonth())
                .build();
    }
}