package com.example.SubscriptionBillingTask.service;


import com.example.SubscriptionBillingTask.audit.AuditService;
import com.example.SubscriptionBillingTask.dto.request.InvoiceRequest;
import com.example.SubscriptionBillingTask.dto.response.InvoiceResponse;
import com.example.SubscriptionBillingTask.enums.InvoiceStatus;
import com.example.SubscriptionBillingTask.exception.BusinessException;
import com.example.SubscriptionBillingTask.exception.ResourceNotFoundException;
import com.example.SubscriptionBillingTask.model.Invoice;
import com.example.SubscriptionBillingTask.model.Subscription;
import com.example.SubscriptionBillingTask.service.repository.InvoiceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;
    private final SubscriptionService subscriptionService;
    private final AuditService auditService;

    public InvoiceResponse generateInvoice(InvoiceRequest request) {
        Subscription subscription = subscriptionService.findById(request.getSubscriptionId());

        String invoiceNumber = "INV-" +
                LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) +
                "-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        Invoice invoice = Invoice.builder()
                .subscription(subscription)
                .invoiceNumber(invoiceNumber)
                .amount(subscription.getPlan().getPrice())
                .status(InvoiceStatus.UNPAID)
                .dueDate(request.getDueDate())
                .build();

        Invoice saved = invoiceRepository.save(invoice);
        auditService.log("INVOICE", "GENERATE", saved.getId(),
                "Invoice generated: " + invoiceNumber, "SYSTEM");
        return toResponse(saved);
    }

    public InvoiceResponse getInvoiceById(Long id) {
        return toResponse(findById(id));
    }

    public Page<InvoiceResponse> getAllInvoices(Pageable pageable) {
        return invoiceRepository.findAll(pageable).map(this::toResponse);
    }

    public Page<InvoiceResponse> getInvoicesByStatus(InvoiceStatus status, Pageable pageable) {
        return invoiceRepository.findByStatus(status, pageable).map(this::toResponse);
    }

    public Page<InvoiceResponse> getInvoicesByUser(Long userId, Pageable pageable) {
        return invoiceRepository.findByUserId(userId, pageable).map(this::toResponse);
    }

    public Page<InvoiceResponse> getInvoicesBySubscription(Long subscriptionId, Pageable pageable) {
        Subscription subscription = subscriptionService.findById(subscriptionId);
        return invoiceRepository.findBySubscription(subscription, pageable).map(this::toResponse);
    }

    public InvoiceResponse markAsPaid(Long id) {
        Invoice invoice = findById(id);
        if (invoice.getStatus() == InvoiceStatus.PAID) {
            throw new BusinessException("Invoice is already paid");
        }
        invoice.setStatus(InvoiceStatus.PAID);
        invoice.setPaidDate(LocalDate.now());
        Invoice saved = invoiceRepository.save(invoice);
        auditService.log("INVOICE", "PAID", id, "Invoice marked as paid: " + invoice.getInvoiceNumber(), "SYSTEM");
        return toResponse(saved);
    }

    public InvoiceResponse cancelInvoice(Long id) {
        Invoice invoice = findById(id);
        if (invoice.getStatus() == InvoiceStatus.PAID) {
            throw new BusinessException("Cannot cancel a paid invoice");
        }
        invoice.setStatus(InvoiceStatus.CANCELLED);
        Invoice saved = invoiceRepository.save(invoice);
        auditService.log("INVOICE", "CANCEL", id, "Invoice cancelled", "SYSTEM");
        return toResponse(saved);
    }

    public Invoice findById(Long id) {
        return invoiceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found with id: " + id));
    }

    private InvoiceResponse toResponse(Invoice i) {
        return InvoiceResponse.builder()
                .id(i.getId())
                .subscriptionId(i.getSubscription().getId())
                .invoiceNumber(i.getInvoiceNumber())
                .amount(i.getAmount())
                .status(i.getStatus())
                .dueDate(i.getDueDate())
                .paidDate(i.getPaidDate())
                .createdAt(i.getCreatedAt())
                .build();
    }
}