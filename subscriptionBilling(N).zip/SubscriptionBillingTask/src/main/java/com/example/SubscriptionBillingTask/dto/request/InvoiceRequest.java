package com.example.SubscriptionBillingTask.dto.request;


import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter 
@NoArgsConstructor 
@AllArgsConstructor
@Builder
public class InvoiceRequest {

    @NotNull(message = "Subscription ID is required")
    private Long subscriptionId;

    @NotNull(message = "Due date is required")
    private LocalDate dueDate;
}
