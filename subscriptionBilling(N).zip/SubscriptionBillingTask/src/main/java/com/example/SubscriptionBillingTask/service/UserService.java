package com.example.SubscriptionBillingTask.service;

import com.example.SubscriptionBillingTask.audit.AuditService;
import com.example.SubscriptionBillingTask.dto.request.UserRequest;
import com.example.SubscriptionBillingTask.dto.response.UserResponse;
import com.example.SubscriptionBillingTask.enums.Role;
import com.example.SubscriptionBillingTask.exception.BusinessException;
import com.example.SubscriptionBillingTask.exception.ResourceNotFoundException;
import com.example.SubscriptionBillingTask.model.User;
import com.example.SubscriptionBillingTask.model.User.UserBuilder;
import com.example.SubscriptionBillingTask.service.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final AuditService auditService;

    public UserResponse createUser(UserRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BusinessException("Email already registered: " + request.getEmail());
        }
        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .phone(request.getPhone())
                .role(request.getRole())
                .password(request.getPassword())
                .active(true)
                .build();
        User saved = userRepository.save(user);
        auditService.log("USER", "CREATE", saved.getId(), "User created: " + saved.getEmail(), "SYSTEM");
        return toResponse(saved);
    }

    public UserResponse getUserById(Long id) {
        return toResponse(findById(id));
    }

    public Page<UserResponse> getAllUsers(Pageable pageable) {
        return userRepository.findAll(pageable).map(this::toResponse);
    }

    public Page<UserResponse> searchUsers(String name, String email, Role role, Pageable pageable) {
        return userRepository.searchUsers(name, email, role, pageable).map(this::toResponse);
    }

    public Page<UserResponse> getUsersByRole(Role role, Pageable pageable) {
        return userRepository.findByRole(role, pageable).map(this::toResponse);
    }

    public UserResponse updateUser(Long id, UserRequest request) {
        User user = findById(id);
        if (!user.getEmail().equals(request.getEmail()) && userRepository.existsByEmail(request.getEmail())) {
            throw new BusinessException("Email already in use: " + request.getEmail());
        }
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        user.setRole(request.getRole());
        user.setPassword(request.getPassword());
        User saved = userRepository.save(user);
        auditService.log("USER", "UPDATE", saved.getId(), "User updated: " + saved.getEmail(), "SYSTEM");
        return toResponse(saved);
    }

    public void deactivateUser(Long id) {
        User user = findById(id);
        user.setActive(false);
        userRepository.save(user);
        auditService.log("USER", "DEACTIVATE", id, "User deactivated", "SYSTEM");
    }

    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }

    private UserResponse toResponse(User u) {
        return UserResponse.builder()
                .id(u.getId())
                .name(u.getName())
                .email(u.getEmail())
                .phone(u.getPhone())
                .role(u.getRole())
                
                .active(u.isActive())
                .createdAt(u.getCreatedAt())
                .updatedAt(u.getUpdatedAt())
                .build();
    }
}