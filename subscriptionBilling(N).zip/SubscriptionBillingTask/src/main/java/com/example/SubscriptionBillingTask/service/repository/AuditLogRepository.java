package com.example.SubscriptionBillingTask.service.repository;



import com.example.SubscriptionBillingTask.model.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    Page<AuditLog> findByEntity(String entity, Pageable pageable);
    Page<AuditLog> findByEntityAndEntityId(String entity, Long entityId, Pageable pageable);
    Page<AuditLog> findByPerformedBy(String performedBy, Pageable pageable);
}
