package com.example.SubscriptionBillingTask.enums;

public enum Role {
    ADMIN, USER, MANAGER
}
