package com.example.SubscriptionBillingTask.exception;



public class BusinessException extends RuntimeException {
    public BusinessException(String message) {
        super(message);
    }
}