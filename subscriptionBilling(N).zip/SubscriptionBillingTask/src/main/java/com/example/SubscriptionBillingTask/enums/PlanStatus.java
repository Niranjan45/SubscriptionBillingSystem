package com.example.SubscriptionBillingTask.enums;


public enum PlanStatus {
    ACTIVE, INACTIVE, DEPRECATED
}