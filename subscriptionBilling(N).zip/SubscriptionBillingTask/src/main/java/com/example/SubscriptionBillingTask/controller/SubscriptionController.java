package com.example.SubscriptionBillingTask.controller;


import com.example.SubscriptionBillingTask.dto.request.SubscriptionRequest;
import com.example.SubscriptionBillingTask.dto.response.SubscriptionResponse;
import com.example.SubscriptionBillingTask.enums.SubscriptionStatus;
import com.example.SubscriptionBillingTask.service.SubscriptionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/subscriptions")
@RequiredArgsConstructor
@Tag(name = "Subscription Management", description = "APIs for managing subscriptions")
public class SubscriptionController {

    private final SubscriptionService subscriptionService;

    @PostMapping
    @Operation(summary = "Create a new subscription")
    public ResponseEntity<SubscriptionResponse> createSubscription(
            @Valid @RequestBody SubscriptionRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(subscriptionService.createSubscription(request));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get subscription by ID")
    public ResponseEntity<SubscriptionResponse> getSubscriptionById(@PathVariable Long id) {
        return ResponseEntity.ok(subscriptionService.getSubscriptionById(id));
    }

    @GetMapping
    @Operation(summary = "Get all subscriptions with pagination")
    public ResponseEntity<Page<SubscriptionResponse>> getAllSubscriptions(Pageable pageable) {
        return ResponseEntity.ok(subscriptionService.getAllSubscriptions(pageable));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get subscriptions by user")
    public ResponseEntity<Page<SubscriptionResponse>> getByUser(
            @PathVariable Long userId, Pageable pageable) {
        return ResponseEntity.ok(subscriptionService.getSubscriptionsByUser(userId, pageable));
    }

    @GetMapping("/status/{status}")
    @Operation(summary = "Get subscriptions by status")
    public ResponseEntity<Page<SubscriptionResponse>> getByStatus(
            @PathVariable SubscriptionStatus status, Pageable pageable) {
        return ResponseEntity.ok(subscriptionService.getSubscriptionsByStatus(status, pageable));
    }

    @PatchMapping("/{id}/cancel")
    @Operation(summary = "Cancel subscription")
    public ResponseEntity<SubscriptionResponse> cancelSubscription(@PathVariable Long id) {
        return ResponseEntity.ok(subscriptionService.cancelSubscription(id));
    }

    @PatchMapping("/{id}/pause")
    @Operation(summary = "Pause subscription")
    public ResponseEntity<SubscriptionResponse> pauseSubscription(@PathVariable Long id) {
        return ResponseEntity.ok(subscriptionService.pauseSubscription(id));
    }

    @PatchMapping("/{id}/resume")
    @Operation(summary = "Resume subscription")
    public ResponseEntity<SubscriptionResponse> resumeSubscription(@PathVariable Long id) {
        return ResponseEntity.ok(subscriptionService.resumeSubscription(id));
    }
}