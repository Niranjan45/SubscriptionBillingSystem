package com.example.SubscriptionBillingTask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubscriptionBillingTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubscriptionBillingTaskApplication.class, args);
	}

}
