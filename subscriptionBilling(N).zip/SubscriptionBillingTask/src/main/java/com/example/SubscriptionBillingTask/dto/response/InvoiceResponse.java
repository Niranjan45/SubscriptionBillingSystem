package com.example.SubscriptionBillingTask.dto.response;



import com.example.SubscriptionBillingTask.enums.InvoiceStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor 
@AllArgsConstructor
@Builder
public class InvoiceResponse {
    private Long id;
    private Long subscriptionId;
    private String invoiceNumber;
    private BigDecimal amount;
    private InvoiceStatus status;
    private LocalDate dueDate;
    private LocalDate paidDate;
    private LocalDateTime createdAt;
}
